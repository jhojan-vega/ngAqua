import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-landpage',
  templateUrl: './landpage.component.html',
  styles: []
})
export class LandpageComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
